//document.write('Bienvenido a java scripts</center></h1>');
//alert('Bienvenido')
['Bienvenido a', 'UP'].forEach(alert)